#!/bin/bash
cd /home/lahnavatar/codebase
source /home/lahnavatar/codebase/bin/activate
python lahn.py
