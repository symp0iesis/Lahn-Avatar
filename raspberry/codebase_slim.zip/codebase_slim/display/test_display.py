from display_manager import DisplayManager
import time

display = DisplayManager(
    flip_display=False,
    #font_path="/usr/share/fonts/truetype/fira/FiraSans-Regular.ttf"
)

# ✅ Set mode before run()
#display.set_mode("text", [
#    "Ich bin ein Ausdrucksmittel, ein symbolisches Abbild des Lahnflusses, entworfen, um die Präsenz, Geschichte und Bedürfnisse des Lahnflusses mit den Menschen zu teilen."
#])
display.set_mode("face")
#display.set_mode("face+text", text="Ich", lang="de")
# Run display loop (press Q to exit)
display.run()
