###########----------- Integration working with text size. improvements to be made regarding speaking more
# display_manager.py - typewrite mode, boxed text, face mode

import cv2
import numpy as np
import time
import threading
import os
import cv2.freetype
from picamera2 import Picamera2

class DisplayManager:
    def __init__(self, flip_display=True, font_path=None, video_folder="."):
        self.flip_display = flip_display
        self.mode = "text"
        self.text_lines = []
        self.font_path = font_path or "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"
        self.font_color = (255, 255, 255)

        self.freetype = cv2.freetype.createFreeType2()
        self.freetype.loadFontData(fontFileName=self.font_path, id=0)

        self.text_overlay_img = None
        self.typewrite_state = {}

        self.face_cascade = cv2.CascadeClassifier("/usr/share/opencv4/haarcascades/haarcascade_frontalface_default.xml")
        self.detected_face = None
        self.latest_frame = None
        self.lost_frame_count = 0
        self.max_lost_frames = 15
        self.face_lock = threading.Lock()
        self.detection_interval = 0.3
        self.last_detection_time = 0

        self.picam2 = Picamera2()
        self.picam2.preview_configuration.main.size = (640, 480)
        self.picam2.preview_configuration.main.format = "RGB888"
        self.picam2.configure("preview")
        self.picam2.start()
        time.sleep(1)

        self.bg_videos = [
            os.path.join(video_folder, f)
            for f in sorted(os.listdir(video_folder))
            if f.lower().endswith(".mp4")
        ]
        if not self.bg_videos:
            raise IOError(f"No video files found in folder: {video_folder}")
        self.bg_video_index = 0
        self.cap = cv2.VideoCapture(self.bg_videos[self.bg_video_index])
        if not self.cap.isOpened():
            raise IOError(f"Could not open video: {self.bg_videos[self.bg_video_index]}")

        self.video_fps = self.cap.get(cv2.CAP_PROP_FPS) or 25
        self.last_frame_time = time.time()
        self.video_start_time = time.time()
        self.video_duration_limit = 60 * 60
        self.running = False

    def set_mode(self, mode, text_lines=None):

        # ─── clear EVERYTHING from any previous text/typewrite run ───
        self.text_overlay_img = None
        self.typewrite_state  = None
        self.text_lines       = []
        # now switch mode
        self.mode = mode        
        if text_lines:
            self.text_lines = text_lines
            self.text_overlay_img = None
            if mode == "typewrite":
                full_text = " ".join(text_lines)
                screen_w, screen_h = 1280, 1024
                lines, font_size, layout_box = self._wrap_and_fit_text(full_text, screen_w, screen_h)
                self.typewrite_state = {
                    "start_time": time.time(),
                    "full_text": full_text,
                    "wrapped_lines": lines,
                    "font_size": font_size,
                    "layout_box": layout_box,
                    "chars_visible": 0,
                    "last_render": None
                }

    def stop(self):
        self.running = False

    def run(self):
        self.running = True
        cv2.namedWindow("River Portal", cv2.WND_PROP_FULLSCREEN)
        cv2.setWindowProperty("River Portal", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        threading.Thread(target=self._face_detection_loop, daemon=True).start()

        while self.running:
            if time.time() - self.video_start_time > self.video_duration_limit:
                self._switch_to_next_video()

            ret, background = self.cap.read()
            if not ret:
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue

            if self.mode == "face":
                self._overlay_face(background)
            elif self.mode == "text":
                self._overlay_text(background)
            elif self.mode == "typewrite":
                self._overlay_typewrite(background)

            if self.flip_display:
                frame_to_show = cv2.rotate(background, cv2.ROTATE_180)
            else:
                frame_to_show = background

            cv2.imshow("River Portal", frame_to_show)

            elapsed = time.time() - self.last_frame_time
            delay = max(0, (1.0 / self.video_fps) - elapsed)
            time.sleep(delay)
            self.last_frame_time = time.time()

            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.running = False

        self.cap.release()
        cv2.destroyAllWindows()

    def _switch_to_next_video(self):
        self.bg_video_index = (self.bg_video_index + 1) % len(self.bg_videos)
        self.cap.release()
        self.cap = cv2.VideoCapture(self.bg_videos[self.bg_video_index])
        if not self.cap.isOpened():
            raise IOError(f"Could not open video: {self.bg_videos[self.bg_video_index]}")
        self.video_fps = self.cap.get(cv2.CAP_PROP_FPS) or 25
        self.video_start_time = time.time()

    def _face_detection_loop(self):
        while self.running:
            frame = self.picam2.capture_array()
            self.latest_frame = frame.copy()

            now = time.time()
            if now - self.last_detection_time >= self.detection_interval:
                gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
                faces = self.face_cascade.detectMultiScale(gray, 1.2, 5)

                with self.face_lock:
                    if len(faces) > 0:
                        self.detected_face = max(faces, key=lambda b: b[2] * b[3])
                        self.lost_frame_count = 0
                    elif self.detected_face is not None and self.lost_frame_count < self.max_lost_frames:
                        self.lost_frame_count += 1
                    else:
                        self.detected_face = None
                        self.lost_frame_count = 0

                self.last_detection_time = now

    def _overlay_face(self, background):
        with self.face_lock:
            face = self.detected_face
            frame = self.latest_frame

        if face is None or frame is None:
            return

        x, y, w, h = face
        pad_top = int(h * 1.2)
        pad_bottom = int(h * 0.8)
        pad_left = int(w * 0.2)
        pad_right = int(w * 0.2)

        y1 = max(0, y - pad_top)
        y2 = min(frame.shape[0], y + h + pad_bottom)
        x1 = max(0, x - pad_left)
        x2 = min(frame.shape[1], x + w + pad_right)

        face_img = frame[y1:y2, x1:x2]
        scale_factor = 1.4
        target_height = int((y2 - y1) * scale_factor)
        target_width = int((x2 - x1) * scale_factor)
        face_resized = cv2.resize(face_img, (target_width, target_height))

        mask = np.zeros((target_height, target_width), dtype=np.uint8)
        center = (target_width // 2, target_height // 2)
        axes = (int(target_width * 0.4), int(target_height * 0.45))
        cv2.ellipse(mask, center, axes, 0, 0, 360, 255, -1)
        blurred_mask = cv2.GaussianBlur(mask, (51, 51), 0)
        alpha = (blurred_mask / 255.0) * 0.8
        alpha = alpha[..., np.newaxis]

        x_offset = (background.shape[1] - target_width) // 2
        y_offset = (background.shape[0] - target_height) // 2
        roi = background[y_offset:y_offset+target_height, x_offset:x_offset+target_width]
        blended = (alpha * face_resized + (1 - alpha) * roi).astype(np.uint8)
        background[y_offset:y_offset+target_height, x_offset:x_offset+target_width] = blended

    def _wrap_and_fit_text(self, text, screen_w, screen_h, max_w=0.55, max_h=0.55, max_font_size=40):
        w, h = int(screen_w * max_w), int(screen_h * max_h)
        x, y = (screen_w - w) // 2, (screen_h - h) // 2

        for size in range(max_font_size, 9, -1):
            words = text.split()
            lines = []
            current = ""
            for word in words:
                test = current + (" " if current else "") + word
                (text_w, _), _ = self.freetype.getTextSize(test, size, thickness=-1)
                if text_w > w:
                    lines.append(current)
                    current = word
                else:
                    current = test
            if current:
                lines.append(current)

            total_height = int(size * 1.5 * len(lines))
            valid = all(self.freetype.getTextSize(line, size, thickness=-1)[0][0] <= w for line in lines)

            if total_height <= h and valid:
                return lines, size, (x, y, w, h)

        return [text], 10, (x, y, w, h)

    def _overlay_text(self, background):
        if not self.text_lines:
            return
        if self.text_overlay_img is None:
            self.text_overlay_img = np.zeros_like(background)
            lines = []
            for entry in self.text_lines:
                if entry.strip() == "":
                    lines.append("")
                else:
                    wrapped, _, _ = self._wrap_and_fit_text(entry, background.shape[1], background.shape[0])
                    lines.extend(wrapped)

            font_size = 36
            line_spacing = int(font_size * 1.5)
            visible_lines = [l for l in lines if l.strip() != ""]
            total_height = line_spacing * len(lines)
            y_start = (background.shape[0] - total_height) // 2

            y = y_start
            for line in lines:
                if line == "":
                    y += line_spacing
                    continue
                (text_w, text_h), _ = self.freetype.getTextSize(line, font_size, thickness=-1)
                x = (background.shape[1] - text_w) // 2
                self.freetype.putText(self.text_overlay_img, line, (x, y + text_h), font_size, self.font_color, thickness=-1, line_type=cv2.LINE_AA, bottomLeftOrigin=False)
                y += line_spacing

        cv2.addWeighted(self.text_overlay_img, 1.0, background, 1.0, 0, dst=background)

    def _overlay_typewrite(self, background):
        if not self.typewrite_state:
            return
        state = self.typewrite_state
        now = time.time()

        full_text = state["full_text"]
        min_speed, max_speed = 0.03, 0.075
        max_chars = 150
        speed = min_speed + (max_speed - min_speed) * min(len(full_text), max_chars) / max_chars
        chars_visible = min(int((now - state["start_time"]) / speed), len(full_text))

        if state.get("chars_visible") == chars_visible and state.get("last_render") is not None:
            cv2.addWeighted(state["last_render"], 1.0, background, 1.0, 0, dst=background)
            return

        font_size = state["font_size"]
        wrapped_lines = state["wrapped_lines"]
        x, y, w, h = state["layout_box"]

        visible_text = full_text[:chars_visible]
        lines = []
        count = 0
        for full_line in wrapped_lines:
            if count + len(full_line) <= chars_visible:
                lines.append(full_line)
                count += len(full_line)
            else:
                remaining = chars_visible - count
                if remaining > 0:
                    lines.append(full_line[:remaining])
                break

        overlay = np.zeros_like(background)
        y_start = y + (h - int(font_size * 1.5 * len(lines))) // 2
        for i, line in enumerate(lines):
            (text_w, text_h), _ = self.freetype.getTextSize(line, font_size, thickness=-1)
            x_pos = x + (w - text_w) // 2
            y_pos = y_start + int(font_size * 1.5 * i) + text_h
            self.freetype.putText(overlay, line, (x_pos, y_pos), font_size, self.font_color, thickness=-1, line_type=cv2.LINE_AA, bottomLeftOrigin=False)

        state["chars_visible"] = chars_visible
        state["last_render"] = overlay
        cv2.addWeighted(overlay, 1.0, background, 1.0, 0, dst=background)


