##########--------- Thinking cue with langid
########---------- Empty messages return to IDLE page. 
########----------- Single taps wonn't trigger Listening during IDLE
#########----------- Thinking uninterrupted by button
#########---------- Speaking uninterrupted by button. BACK to IDLE
############--------  integration with buffer time post speak leading to 
############--------  listening when button pressed/held
###########=========== integration with buffer time post speak
########## ----------- Basic integration working. improvements to be made

import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 10.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 3.0       # second pre-thinking message is shown
POST_SPEAK_BUFFER  = 5.0       # seconds to keep typewrite text post-speak

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {'Content-Type': 'application/json'}

# === Global state + LEDs + flags ===
listening                    = False
speech_data                  = np.array([])
tts_running                  = Event()
skip_thinking_event          = Event()
user_interacted_during_buffer= Event()
press_time                   = 0
pressed                      = False
last_interaction_time        = 0
thinking_phase               = False        # NEW: gate presses/releases during LLM thinking

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)

# === IDLE TEXT ===
idle_text = [
    "Hallo. Ich bin das Lahn-Avatar. Setz dir die Kopfhörer auf, drücke und HALTE den roten Knopf, um mit mir zu sprechen. Weiße Lichter werden blinken, damit ich dich hören kann.",
    "",
    "Hello. I am the Lahn Avatar. Put on the headphones, press and HOLD the red button to talk to me. White lights will flash so I can hear you.",
]

# === LISTENING TEXT ===
listening_text = [
    "Halte den Knopf weiterhin gedrückt. Du kannst jetzt sprechen. Wenn du fertig bist, lass den Knopf los, um deine Nachricht zu senden.",
    "",
    "Keep holding the button. You can speak now. When you are done, release the button to send your message.",
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Ich bearbeite jetzt Ihre Nachricht.",
    "Denke über die Lahn nach, während du wartest.",
    "",
    "I am now processing your message.",
    "Reflect on the Lahn while you wait."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        global thinking_phase
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()

            # START SPEAKING → clear thinking_phase so further presses are gated by tts_running
            tts_running.set()
            thinking_phase = False
            led.set_speaking()
            display.set_mode("typewrite", [text])

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

            # post-speak buffering & return to idle display
            user_interacted_during_buffer.clear()
            time.sleep(POST_SPEAK_BUFFER)
            if not user_interacted_during_buffer.is_set():
                display.set_mode("text", idle_text)
            user_interacted_during_buffer.clear()
            
        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    global thinking_phase
    # ENTER thinking phase: ignore presses/releases during LLM call
    thinking_phase = True

    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")
            play_thinking_cue(detected_lang if detected_lang in THINKING_WAVS else "en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    
    print(f"Detected ({detected_lang}): {full_text}")
    # Return to IDLE if transcript is empty
    if not full_text.strip():
        print("No speech detected; returning to IDLE state.")
        avatar_done.set()  # prevent thinking indicators
        thinking_phase = False
        led.set_idle()
        display.set_mode("text", idle_text)
        return
        
    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        #display.set_mode("typewrite", [reply])
        
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    # only start listening if the button is still down, TTS isn't running,
    # and we're not already in listening mode
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring input")
        return
    if listening:
        return
    skip_thinking_event.clear()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring press: still thinking")
        return
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring press")
        return

    print("Button pressed")
    press_time = now
    pressed = True
    user_interacted_during_buffer.set()
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring release: still thinking")
        return
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring release")
        return

    print("Button released")
    # compute how long the button was held
    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    # if it was just a tap, ignore entirely
    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        return

    # otherwise it's a real hold → stop listening & show "thinking"
    print("Button released after hold")
    listening = False
    display.set_mode("text", prethinking_text)
    threading.Thread(
        target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")),
        daemon=True
    ).start()
    time.sleep(0.2)
    respond()


# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()

    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()



########---------- Empty messages return to IDLE page.
########----------- Single taps wonn't trigger Listening during IDLE
#########----------- Thinking uninterrupted by button
#########---------- Speaking uninterrupted by button. BACK to IDLE
############--------  integration with buffer time post speak leading to 
############--------  listening when button pressed/held
###########=========== integration with buffer time post speak
########## ----------- Basic integration working. improvements to be made

import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 10.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 3.0       # second pre-thinking message is shown
POST_SPEAK_BUFFER  = 5.0       # seconds to keep typewrite text post-speak

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {'Content-Type': 'application/json'}

# === Global state + LEDs + flags ===
listening                    = False
speech_data                  = np.array([])
tts_running                  = Event()
skip_thinking_event          = Event()
user_interacted_during_buffer= Event()
press_time                   = 0
pressed                      = False
last_interaction_time        = 0
thinking_phase               = False        # NEW: gate presses/releases during LLM thinking

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)

# === IDLE TEXT ===
idle_text = [
    "Hallo. Ich bin das Lahn-Avatar. Setz dir die Kopfhörer auf, drücke und HALTE den roten Knopf, um mit mir zu sprechen. Weiße Lichter werden blinken, damit ich dich hören kann.",
    "",
    "Hello. I am the Lahn Avatar. Put on the headphones, press and HOLD the red button to talk to me. White lights will flash so I can hear you.",
]

# === LISTENING TEXT ===
listening_text = [
    "Halte den Knopf weiterhin gedrückt. Du kannst jetzt sprechen. Wenn du fertig bist, lass den Knopf los, um deine Nachricht zu senden.",
    "",
    "Keep holding the button. You can speak now. When you are done, release the button to send your message.",
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Ich bearbeite jetzt Ihre Nachricht.",
    "Denke über die Lahn nach, während du wartest.",
    "",
    "I am now processing your message.",
    "Reflect on the Lahn while you wait."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        global thinking_phase
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()

            # START SPEAKING → clear thinking_phase so further presses are gated by tts_running
            tts_running.set()
            thinking_phase = False
            led.set_speaking()
            display.set_mode("typewrite", [text])

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

            # post-speak buffering & return to idle display
            user_interacted_during_buffer.clear()
            time.sleep(POST_SPEAK_BUFFER)
            if not user_interacted_during_buffer.is_set():
                display.set_mode("text", idle_text)
            user_interacted_during_buffer.clear()

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    global thinking_phase
    # ENTER thinking phase: ignore presses/releases during LLM call
    thinking_phase = True

    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    
    print(f"Detected ({detected_lang}): {full_text}")
    # Return to IDLE if transcript is empty
    if not full_text.strip():
        print("No speech detected; returning to IDLE state.")
        avatar_done.set()  # prevent thinking indicators
        thinking_phase = False
        led.set_idle()
        display.set_mode("text", idle_text)
        return
        
    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        #display.set_mode("typewrite", [reply])
        
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    # only start listening if the button is still down, TTS isn't running,
    # and we're not already in listening mode
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring input")
        return
    if listening:
        return
    skip_thinking_event.clear()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring press: still thinking")
        return
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring press")
        return

    print("Button pressed")
    press_time = now
    pressed = True
    user_interacted_during_buffer.set()
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring release: still thinking")
        return
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring release")
        return

    print("Button released")
    # compute how long the button was held
    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    # if it was just a tap, ignore entirely
    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        return

    # otherwise it's a real hold → stop listening & show "thinking"
    print("Button released after hold")
    listening = False
    display.set_mode("text", prethinking_text)
    threading.Thread(
        target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")),
        daemon=True
    ).start()
    time.sleep(0.2)
    respond()


# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()

    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()





########----------- Single taps wonn't trigger Listening during IDLE

#########----------- Thinking uninterrupted by button

#########---------- Speaking uninterrupted by button. BACK to IDLE

############--------  integration with buffer time post speak leading to 
############--------  listening when button pressed/held

###########=========== integration with buffer time post speak
########## ----------- Basic integration working. improvements to be made

import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 15.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 7.0       # second pre-thinking message is shown
POST_SPEAK_BUFFER  = 5.0       # seconds to keep typewrite text post-speak

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {'Content-Type': 'application/json'}

# === Global state + LEDs + flags ===
listening                    = False
speech_data                  = np.array([])
tts_running                  = Event()
skip_thinking_event          = Event()
user_interacted_during_buffer= Event()
press_time                   = 0
pressed                      = False
last_interaction_time        = 0
thinking_phase               = False        # NEW: gate presses/releases during LLM thinking

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)

# === IDLE TEXT ===
idle_text = [
    "Hallo. Ich bin das Lahn-Avatar. Setz dir die Kopfhörer auf, drücke und HALTE den roten Knopf, um mit mir zu sprechen. Weiße Lichter werden blinken, damit ich dich hören kann.",
    "",
    "Hello. I am the Lahn Avatar. Put on the headphones, press and HOLD the red button to talk to me. White lights will flash so I can hear you.",
]

# === LISTENING TEXT ===
listening_text = [
    "Halte den Knopf weiterhin gedrückt. Du kannst jetzt sprechen. Wenn du fertig bist, lass den Knopf los, um deine Nachricht zu senden.",
    "",
    "Keep holding the button. You can speak now. When you are done, release the button to send your message.",
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Ich bearbeite jetzt Ihre Nachricht.",
    "Denke über die Lahn nach, während du wartest.",
    "",
    "I am now processing your message.",
    "Reflect on the Lahn while you wait."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        global thinking_phase
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()

            # START SPEAKING → clear thinking_phase so further presses are gated by tts_running
            tts_running.set()
            thinking_phase = False
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

            # post-speak buffering & return to idle display
            user_interacted_during_buffer.clear()
            time.sleep(POST_SPEAK_BUFFER)
            if not user_interacted_during_buffer.is_set():
                display.set_mode("text", idle_text)
            user_interacted_during_buffer.clear()

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    global thinking_phase
    # ENTER thinking phase: ignore presses/releases during LLM call
    thinking_phase = True

    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        display.set_mode("typewrite", [reply])
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    # only start listening if the button is still down, TTS isn't running,
    # and we're not already in listening mode
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring input")
        return
    if listening:
        return
    skip_thinking_event.clear()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring press: still thinking")
        return
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring press")
        return

    print("Button pressed")
    press_time = now
    pressed = True
    user_interacted_during_buffer.set()
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring release: still thinking")
        return
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring release")
        return

    print("Button released")
    # compute how long the button was held
    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    # if it was just a tap, ignore entirely
    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        return

    # otherwise it's a real hold → stop listening & show "thinking"
    print("Button released after hold")
    listening = False
    display.set_mode("text", prethinking_text)
    threading.Thread(
        target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")),
        daemon=True
    ).start()
    time.sleep(0.2)
    respond()


# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()

    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()


#########----------- Thinking uninterrupted by button

#########---------- Speaking uninterrupted by button. BACK to IDLE

############--------  integration with buffer time post speak leading to 
############--------  listening when button pressed/held

###########=========== integration with buffer time post speak
########## ----------- Basic integration working. improvements to be made


import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 15.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 7.0       # second pre-thinking message is shown
POST_SPEAK_BUFFER  = 5.0       # seconds to keep typewrite text post-speak

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {'Content-Type': 'application/json'}

# === Global state + LEDs + flags ===
listening                    = False
speech_data                  = np.array([])
tts_running                  = Event()
skip_thinking_event          = Event()
user_interacted_during_buffer= Event()
press_time                   = 0
pressed                      = False
last_interaction_time        = 0
thinking_phase               = False        # NEW: gate presses/releases during LLM thinking

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)

# === IDLE TEXT ===
idle_text = [
    "Hallo. Ich bin das Lahn-Avatar. Setz dir die Kopfhörer auf, drücke und HALTE den roten Knopf, um mit mir zu sprechen. Weiße Lichter werden blinken, damit ich dich hören kann.",
    "",
    "Hello. I am the Lahn Avatar. Put on the headphones, press and HOLD the red button to talk to me. White lights will flash so I can hear you.",
]

# === LISTENING TEXT ===
listening_text = [
    "Halte den Knopf weiterhin gedrückt. Du kannst jetzt sprechen. Wenn du fertig bist, lass den Knopf los, um deine Nachricht zu senden.",
    "",
    "Keep holding the button. You can speak now. When you are done, release the button to send your message.",
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Ich bearbeite jetzt Ihre Nachricht.",
    "Denke über die Lahn nach, während du wartest.",
    "",
    "I am now processing your message.",
    "Reflect on the Lahn while you wait."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        global thinking_phase
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()

            # START SPEAKING → clear thinking_phase so further presses are gated by tts_running
            tts_running.set()
            thinking_phase = False
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

            # post-speak buffering & return to idle display
            user_interacted_during_buffer.clear()
            time.sleep(POST_SPEAK_BUFFER)
            if not user_interacted_during_buffer.is_set():
                display.set_mode("text", idle_text)
            user_interacted_during_buffer.clear()

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    global thinking_phase
    # ENTER thinking phase: ignore presses/releases during LLM call
    thinking_phase = True

    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        display.set_mode("typewrite", [reply])
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring input")
        return
    skip_thinking_event.clear()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring press: still thinking")
        return
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring press")
        return

    print("Button pressed")
    press_time = now
    pressed = True
    user_interacted_during_buffer.set()
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    # IGNORE during thinking phase
    if thinking_phase:
        print("…ignoring release: still thinking")
        return
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring release")
        return

    print("Button released")
    display.set_mode("text", prethinking_text)
    threading.Thread(
        target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")),
        daemon=True
    ).start()

    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        if listening:
            skip_thinking_event.set()
            led.set_idle()
        return

    listening = False
    time.sleep(0.2)
    respond()

# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()

    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()


#########---------- Speaking uninterrupted by button. BACK to IDLE

############--------  integration with buffer time post speak leading to 
############--------  listening when button pressed/held

###########=========== integration with buffer time post speak
########## ----------- Basic integration working. improvements to be made


import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 15.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 7.0       # second pre-thinkin message is shown
POST_SPEAK_BUFFER  = 5.0  # seconds to keep typewrite text on screen after speaking

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {
    'Content-Type': 'application/json'
}

# === Global state + LEDs + flags ===
listening              = False
speech_data            = np.array([])
tts_running            = Event()
skip_thinking_event    = Event()
user_interacted_during_buffer = Event()
press_time             = 0
pressed                = False
last_interaction_time  = 0

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)  # NEW

# === IDLE TEXT ===
idle_text = [
    "Hallo. Ich bin das Lahn-Avatar. Setz dir die Kopfhörer auf, drücke und HALTE den roten Knopf, um mit mir zu sprechen. Weiße Lichter werden blinken, damit ich dich hören kann.",
    "",
    "Hello. I am the Lahn Avatar. Put on the headphones, press and HOLD the red button to talk to me. White lights will flash so I can hear you.",
]

# === LISTENING TEXT ===
listening_text = [
    "Halte den Knopf weiterhin gedrückt. Du kannst jetzt sprechen. Wenn du fertig bist, lass den Knopf los, um deine Nachricht zu senden.",
    "",
    "Keep holding the button. You can speak now. When you are done, release the button to send your message.",
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Ich bearbeite jetzt Ihre Nachricht.",
    "Denke über die Lahn nach, während du wartest.",
    "",
    "I am now processing your message.",
    "Reflect on the Lahn while you wait."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()
            tts_running.set()
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()
            # clear any “left-over” presses so only new ones count
            user_interacted_during_buffer.clear()
            time.sleep(POST_SPEAK_BUFFER)
            if not user_interacted_during_buffer.is_set():
                display.set_mode("text", idle_text)
            user_interacted_during_buffer.clear()

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        display.set_mode("typewrite", [reply])
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring input")
        return
    skip_thinking_event.clear()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring press")
        return
    print("Button pressed")
    press_time = now
    pressed = True
    user_interacted_during_buffer.set()
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    if not pressed:
        return
    if tts_running.is_set():
        print("TTS is running — ignoring release")
        return

    print("Button released")
    display.set_mode("text", prethinking_text)
    threading.Thread(target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")), daemon=True).start()
    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        if listening:
            skip_thinking_event.set()
            led.set_idle()
        return

    listening = False
    time.sleep(0.2)
    respond()

# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()  # NEW

    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()



###########=========== integration with buffer time post speak
########## ----------- Basic integration working. improvements to be made

import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 15.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 7.0       # second pre-thinkin message is shown
POST_SPEAK_BUFFER  = 7.0  # seconds to keep typewrite text on screen after speaking


# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {
    'Content-Type': 'application/json'
}

# === Global state + LEDs + flags ===
listening              = False
speech_data            = np.array([])
tts_interrupted        = Event()
tts_running            = Event()
stt_ready_to_listen    = Event()
skip_thinking_event    = Event()
press_time             = 0
pressed                = False
last_interaction_time  = 0

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)  # NEW

# === IDLE TEXT ===
idle_text = [
    "Hallo. Ich bin das Lahn-Avatar. Setz dir die Kopfhörer auf, drücke und HALTE den roten Knopf, um mit mir zu sprechen. Weiße Lichter werden blinken, damit ich dich hören kann.",
    "",
    "Hello. I am the Lahn Avatar. Put on the headphones, press and HOLD the red button to talk to me. White lights will flash so I can hear you.",
]

# === LISTENING TEXT ===
listening_text = [
    "Halte den Knopf weiterhin gedrückt. Du kannst jetzt sprechen. Wenn du fertig bist, lass den Knopf los, um deine Nachricht zu senden.",
    "",
    "Keep holding the button. You can speak now. When you are done, release the button to send your message.",
    
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Ich bearbeite jetzt Ihre Nachricht.",
    "Denke über die Lahn nach, während du wartest.",
    "",
    "I am now processing your message.",
    "Reflect on the Lahn while you wait."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()
            tts_running.set()
            tts_interrupted.clear()
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    if tts_interrupted.is_set():
                        print("TTS interrupted by button press.")
                        stream.abort(); stream.close()
                        tts_running.clear()
                        stt_ready_to_listen.set()
                        led.clear()
                        return
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        if tts_interrupted.is_set():
                            print("TTS interrupted mid-chunk.")
                            stream.abort(); stream.close()
                            tts_running.clear()
                            stt_ready_to_listen.set()
                            led.clear()
                            return
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            stt_ready_to_listen.set()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()
            # Hold final message on screen briefly
            time.sleep(POST_SPEAK_BUFFER)
            # Return to IDLE display mode
            display.set_mode("text", idle_text)

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            stt_ready_to_listen.set()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    # NEW: Set display to LISTENING MODE
    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")  # NEW: Show face mode while thinking
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        display.set_mode("typewrite", [reply])
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    if not pressed:
        return
    skip_thinking_event.clear()
    if tts_running.is_set():
        print("Interrupting TTS...")
        tts_interrupted.set()
        stt_ready_to_listen.wait()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    print("Button pressed")
    press_time = now
    pressed = True
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    if not pressed:
        return
    print("Button released")

    # NEW: Briefly show intermediary text before face mode
    display.set_mode("text", prethinking_text)
    threading.Thread(target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")), daemon=True).start()
    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        if listening:
            skip_thinking_event.set()
            led.set_idle()
        return

    listening = False
    time.sleep(0.2)
    respond()

# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()  # NEW

    # === Set display to IDLE MODE with instructions ===
    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()




########## ----------- Basic integration working. improvements to be made

import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController
from display.display_manager import DisplayManager  # NEW
import os  # NEW

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 10.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps
THINKING_MES       = 5.0       # second pre-thinkin message is shown

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {
    'Content-Type': 'application/json'
}

# === Global state + LEDs + flags ===
listening              = False
speech_data            = np.array([])
tts_interrupted        = Event()
tts_running            = Event()
stt_ready_to_listen    = Event()
skip_thinking_event    = Event()
press_time             = 0
pressed                = False
last_interaction_time  = 0

led = LahnLEDController()

# NEW: Pass correct video path from display folder
current_dir = os.path.dirname(os.path.abspath(__file__))
display_video_path = os.path.join(current_dir, "display")
display = DisplayManager(flip_display=False, video_folder=display_video_path)  # NEW

# === IDLE TEXT ===
idle_text = [
    "Hello. I am the Lahn Avatar.",
    "Press and hold the red button to be able to talk to me.",
    "You can speak when my light starts blinking in white.",
    "\nHallo. Ich bin der Lahn-Avatar.",
    "Halte den roten Knopf gedrückt, um mit mir zu sprechen.",
    "Wenn mein Licht weiß blinkt, kannst du reden."
]

# === LISTENING TEXT ===
listening_text = [
    "Speak while you hold the button and my light flashes white.",
    "Release the button to send your message and wait for a response.",
    "Sprich, während du den Knopf gedrückt hältst und mein Licht weiß blinkt.",
    "Lass den Knopf los, um deine Nachricht zu senden und auf eine Antwort zu warten."
]

# === PRE-THINKING TEXT ===
prethinking_text = [
    "Sending message. Reflect while you wait.",
    "Nachricht wird gesendet. Denke nach, während du wartest."
]

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()
            tts_running.set()
            tts_interrupted.clear()
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    if tts_interrupted.is_set():
                        print("TTS interrupted by button press.")
                        stream.abort(); stream.close()
                        tts_running.clear()
                        stt_ready_to_listen.set()
                        led.clear()
                        return
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        if tts_interrupted.is_set():
                            print("TTS interrupted mid-chunk.")
                            stream.abort(); stream.close()
                            tts_running.clear()
                            stt_ready_to_listen.set()
                            led.clear()
                            return
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            stt_ready_to_listen.set()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

            # NEW: Return to IDLE display mode
            display.set_mode("text", idle_text)

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            stt_ready_to_listen.set()
            led.set_error()

    print(" ✅ TTS ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    # NEW: Set display to LISTENING MODE
    display.set_mode("text", listening_text)

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()

def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")

def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")

def respond():
    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            display.set_mode("face")  # NEW: Show face mode while thinking
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    history.append({'sender': 'User', 'text': full_text})

    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )

def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        display.set_mode("typewrite", [reply])
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()

def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    if not pressed:
        return
    skip_thinking_event.clear()
    if tts_running.is_set():
        print("Interrupting TTS...")
        tts_interrupted.set()
        stt_ready_to_listen.wait()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    print("Button pressed")
    press_time = now
    pressed = True
    threading.Thread(target=hold_detector, daemon=True).start()

def on_release():
    global listening, press_time, pressed, last_interaction_time
    if not pressed:
        return
    print("Button released")

    # NEW: Briefly show intermediary text before face mode
    display.set_mode("text", prethinking_text)
    threading.Thread(target=lambda: (time.sleep(THINKING_MES), display.set_mode("face")), daemon=True).start()
    duration = time.time() - press_time
    pressed = False
    last_interaction_time = time.time()

    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        if listening:
            skip_thinking_event.set()
            led.set_idle()
        return

    listening = False
    time.sleep(0.2)
    respond()

# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")

    threading.Thread(target=display.run, daemon=True).start()  # NEW

    # === Set display to IDLE MODE with instructions ===
    display.set_mode("text", idle_text)

    led.set_idle()
    init_stt()
    init_tts()

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()



###### Last lanh.py before display_manager integration
import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 10.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {
    'Content-Type': 'application/json'
}

# === Global state + LEDs + flags ===
listening              = False
speech_data            = np.array([])
tts_interrupted        = Event()
tts_running            = Event()
stt_ready_to_listen    = Event()
skip_thinking_event    = Event()
press_time             = 0
pressed                = False
last_interaction_time  = 0

led = LahnLEDController()

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()
            tts_running.set()
            tts_interrupted.clear()
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    if tts_interrupted.is_set():
                        print("TTS interrupted by button press.")
                        stream.abort(); stream.close()
                        tts_running.clear()
                        stt_ready_to_listen.set()
                        led.clear()
                        return
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    # chunked playback
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        if tts_interrupted.is_set():
                            print("TTS interrupted mid-chunk.")
                            stream.abort(); stream.close()
                            tts_running.clear()
                            stt_ready_to_listen.set()
                            led.clear()
                            return
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            stt_ready_to_listen.set()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            stt_ready_to_listen.set()
            led.set_error()

    print(" ✅ TTS ready.")

# === Initialize Retune (commented out for custom LLM) ===
# def init_retune():
#     global generate_response_url, headers, json_data
#     print("\n Initializing Retune connection...")
#     create_thread_url   = 'https://retune.so/api/chat/11f019dd-2f2f-2110-85e9-89c7f1bd0b29/new-thread'
#     generate_response_url = 'https://retune.so/api/chat/11f019dd-2f2f-2110-85e9-89c7f1bd0b29/response'
#     headers = {
#         'Content-Type': 'application/json',
#         'X-Workspace-API-Key': '11ee2f36-c329-7e80-9c79-ff4ddae14db0',
#     }
#     response = requests.get(create_thread_url, headers=headers)
#     threadId = response.json()['threadId']
#     json_data = {
#         'threadId': threadId,
#         'input': 'Hello! Please speak English to me. What are you about?',
#     }
#     print(" ✅ Retune ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    """Record while listening=True; on exit, only fire thinking if not skipped."""
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()


def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")


def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")


def respond():
    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    # Append user message to history
    history.append({'sender': 'User', 'text': full_text})

    # Send to custom LLM instead of Retune
    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )


def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        # Append avatar response to history
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()


def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    if not pressed:
        return
    # Long press: clear skip, then either interrupt or start listening
    skip_thinking_event.clear()
    if tts_running.is_set():
        print("Interrupting TTS...")
        tts_interrupted.set()
        stt_ready_to_listen.wait()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    # ignore if still in cooldown
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    print("Button pressed")
    press_time = now
    pressed = True
    threading.Thread(target=hold_detector, daemon=True).start()


def on_release():
    global listening, press_time, pressed, last_interaction_time
    if not pressed:
        return
    print("Button released")
    duration = time.time() - press_time
    pressed = False
    # start cooldown
    last_interaction_time = time.time()

    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        # only suppress thinking pattern if we were actively listening
        if listening:
            skip_thinking_event.set()
            led.set_idle()
        return

    # Long-press release: stop listening & respond
    listening = False
    time.sleep(0.2)
    respond()

# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")
    led.set_idle()
    init_stt()
    init_tts()
    # init_retune()  # Commented out: using custom LLM instead

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()


##############---------------------##############-------------##########

import time
import threading
import numpy as np
import torch
import sounddevice as sd
import requests
import soundfile as sf
from gpiozero import Button
from signal import pause
from faster_whisper import WhisperModel
from langdetect import detect
from piper import PiperVoice
from threading import Event
from led_controller import LahnLEDController

# === CONFIGURATION ===
BUTTON_PIN         = 15
SAMPLE_RATE        = 16000
CHUNK              = 1024
MODEL_SIZE         = "base"
LENGTH_SCALE       = "0.9"
DEVICE_INDEX       = None
THINKING_DELAY     = 10.0      # seconds before playing thinking cue
CHUNK_DURATION     = 0.05      # seconds per audio chunk
MIN_HOLD_TIME      = 1.0       # seconds
TAP_COOLDOWN       = 2.0       # seconds to ignore new taps

# === Piper model paths ===
MODELS = {
    'de': {
        "model": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx",
        "config": "/home/lahnavatar/piper/de_DE-eva_k-x_low.onnx.json"
    },
    'en': {
        "model": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx",
        "config": "/home/lahnavatar/piper/en_GB-jenny_dioco-medium.onnx.json"
    }
}

THINKING_WAVS = {
    'de': "/home/lahnavatar/codebase/thinking_de.wav",
    'en': "/home/lahnavatar/codebase/thinking_en.wav"
}

# === Custom LLM setup variables ===
history = []
generate_response_url = 'https://lahn-server.eastus.cloudapp.azure.com:5001/api/chat'
headers = {
    'Content-Type': 'application/json'
}

# === Global state + LEDs + flags ===
listening              = False
speech_data            = np.array([])
tts_interrupted        = Event()
tts_running            = Event()
stt_ready_to_listen    = Event()
skip_thinking_event    = Event()
press_time             = 0
pressed                = False
last_interaction_time  = 0

led = LahnLEDController()

# === Initialize STT ===
def init_stt():
    global stt_model
    print("\n Initializing Speech-to-Text (FasterWhisper)...")
    stt_model = WhisperModel(MODEL_SIZE, compute_type="int8")
    print(" ✅ STT initialized.")

# === Initialize TTS ===
def init_tts():
    global speak, detect_language
    print("\n Initializing TTS with Piper streaming...")

    voices = {
        lang: PiperVoice.load(paths["model"], paths["config"])
        for lang, paths in MODELS.items()
    }

    def detect_language(text):
        try:
            lang = detect(text)
            return 'de' if lang.startswith('de') else 'en'
        except:
            return 'en'

    def speak(text):
        lang = detect_language(text)
        voice = voices.get(lang, voices['en'])

        print(f"[ {lang.upper()}] Speaking: {text}")
        try:
            start_time = time.time()
            stream = sd.OutputStream(
                samplerate=voice.config.sample_rate,
                channels=1, dtype='int16'
            )
            stream.start()
            tts_running.set()
            tts_interrupted.clear()
            led.set_speaking()

            sentences = text.strip().split(". ")
            for sentence in sentences:
                for audio_bytes in voice.synthesize_stream_raw(sentence):
                    if tts_interrupted.is_set():
                        print("TTS interrupted by button press.")
                        stream.abort(); stream.close()
                        tts_running.clear()
                        stt_ready_to_listen.set()
                        led.clear()
                        return
                    int_data = np.frombuffer(audio_bytes, dtype=np.int16)
                    # chunked playback
                    step = int(SAMPLE_RATE * CHUNK_DURATION)
                    for i in range(0, len(int_data), step):
                        if tts_interrupted.is_set():
                            print("TTS interrupted mid-chunk.")
                            stream.abort(); stream.close()
                            tts_running.clear()
                            stt_ready_to_listen.set()
                            led.clear()
                            return
                        chunk = int_data[i:i+step]
                        stream.write(chunk)

            stream.stop(); stream.close()
            tts_running.clear()
            stt_ready_to_listen.set()
            end_time = time.time()
            print(f"TTS inference + playback time: {end_time - start_time:.2f} seconds")
            led.set_idle()

        except Exception as e:
            print(f" Error during TTS: {e}")
            tts_running.clear()
            stt_ready_to_listen.set()
            led.set_error()

    print(" ✅ TTS ready.")

# === Initialize Retune (commented out for custom LLM) ===
# def init_retune():
#     global generate_response_url, headers, json_data
#     print("\n Initializing Retune connection...")
#     create_thread_url   = 'https://retune.so/api/chat/11f019dd-2f2f-2110-85e9-89c7f1bd0b29/new-thread'
#     generate_response_url = 'https://retune.so/api/chat/11f019dd-2f2f-2110-85e9-89c7f1bd0b29/response'
#     headers = {
#         'Content-Type': 'application/json',
#         'X-Workspace-API-Key': '11ee2f36-c329-7e80-9c79-ff4ddae14db0',
#     }
#     response = requests.get(create_thread_url, headers=headers)
#     threadId = response.json()['threadId']
#     json_data = {
#         'threadId': threadId,
#         'input': 'Hello! Please speak English to me. What are you about?',
#     }
#     print(" ✅ Retune ready.")

# === Listening / Thinking / Responding logic ===

def listen():
    """Record while listening=True; on exit, only fire thinking if not skipped."""
    global speech_data
    print("Listening...")
    speech_data = np.array([])

    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32'
    )
    with stream:
        while listening:
            data, _ = stream.read(CHUNK)
            speech_data = np.append(speech_data, data)

    print("Listening stopped.")
    if not skip_thinking_event.is_set():
        led.set_thinking()
    else:
        skip_thinking_event.clear()


def play_thinking_cue(lang):
    wav_path = THINKING_WAVS.get(lang)
    if not wav_path:
        return
    try:
        data, samplerate = sf.read(wav_path, dtype='int16')
        stream = sd.OutputStream(
            samplerate=samplerate,
            channels=data.shape[1] if data.ndim>1 else 1,
            dtype='int16'
        )
        stream.start()
        stream.write(data)
        stream.stop()
        stream.close()
    except Exception as e:
        print(f"Error playing thinking cue: {e}")


def play_background_loop():
    try:
        data, samplerate = sf.read(
            "/home/lahnavatar/codebase/hydrophone.wav", dtype='int16'
        )
        channels = data.shape[1] if data.ndim>1 else 1
        while True:
            stream = sd.OutputStream(
                samplerate=samplerate,
                channels=channels,
                dtype='int16'
            )
            stream.start()
            stream.write(data)
            stream.stop()
            stream.close()
    except Exception as e:
        print(f"Error playing background loop: {e}")


def respond():
    print("Transcribing...")
    speech_audio = speech_data.astype(np.float32)

    thinking_started = threading.Event()
    avatar_done      = threading.Event()

    def delayed_thinking():
        if not avatar_done.wait(timeout=THINKING_DELAY):
            thinking_started.set()
            led.set_thinking()
            play_thinking_cue("en")

    thinking_thread = threading.Thread(
        target=delayed_thinking, daemon=True
    )
    thinking_thread.start()

    segments, info = stt_model.transcribe(
        speech_audio, language=None, beam_size=1
    )
    detected_lang = info.language
    full_text     = " ".join(seg.text for seg in segments)
    print(f"Detected ({detected_lang}): {full_text}")

    # Append user message to history
    history.append({'sender': 'User', 'text': full_text})

    # Send to custom LLM instead of Retune
    send_to_avatar(
        full_text, detected_lang,
        thinking_thread, thinking_started, avatar_done
    )


def send_to_avatar(text, lang, thinking_thread, thinking_started, avatar_done):
    print("Getting response from Avatar...")
    try:
        response = requests.post(
            generate_response_url,
            headers=headers,
            json={'history': history, 'prompt': text}
        )
        avatar_done.set()

        if response.status_code != 200:
            raise Exception("Avatar API Error")
        reply = response.json()['reply']
        # Append avatar response to history
        history.append({'sender': 'Lahn', 'text': reply})
        print(f"Avatar says: {reply}")

        if thinking_started.is_set():
            thinking_thread.join()
        threading.Thread(
            target=speak, args=(reply,), daemon=True
        ).start()

    except Exception as e:
        print(f"Failed to get Avatar response: {e}")
        led.set_error()
        avatar_done.set()

# === NEW: hold-vs-tap detection helpers ===

def start_listening():
    global listening
    listening = True
    led.set_listening()
    threading.Thread(target=listen, daemon=True).start()


def hold_detector():
    time.sleep(MIN_HOLD_TIME)
    if not pressed:
        return
    # Long press: clear skip, then either interrupt or start listening
    skip_thinking_event.clear()
    if tts_running.is_set():
        print("Interrupting TTS...")
        tts_interrupted.set()
        stt_ready_to_listen.wait()
    start_listening()

# === Button Control with tap-cooldown ===

button = Button(BUTTON_PIN, pull_up=True, bounce_time=0.1)

def on_press():
    global press_time, pressed, last_interaction_time
    now = time.time()
    # ignore if still in cooldown
    if now - last_interaction_time < TAP_COOLDOWN:
        return
    print("Button pressed")
    press_time = now
    pressed = True
    threading.Thread(target=hold_detector, daemon=True).start()


def on_release():
    global listening, press_time, pressed, last_interaction_time
    if not pressed:
        return
    print("Button released")
    duration = time.time() - press_time
    pressed = False
    # start cooldown
    last_interaction_time = time.time()

    if duration < MIN_HOLD_TIME:
        print("Ignored short press")
        # only suppress thinking pattern if we were actively listening
        if listening:
            skip_thinking_event.set()
            led.set_idle()
        return

    # Long-press release: stop listening & respond
    listening = False
    time.sleep(0.2)
    respond()

# === Main ===
def main():
    print("\n Initializing Lahn Avatar...")
    led.set_idle()
    init_stt()
    init_tts()
    # init_retune()  # Commented out: using custom LLM instead

    threading.Thread(
        target=play_background_loop, daemon=True
    ).start()

    button.when_pressed = on_press
    button.when_released = on_release
    print(" \n✅ Lahn Avatar is ready. Hold the button to talk.")
    pause()

if __name__ == "__main__":
    main()
