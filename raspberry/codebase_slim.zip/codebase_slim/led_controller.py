import time
import threading
from pi5neo import Pi5Neo

# === LED Configuration ===
LED_COUNT = 229
SPI_DEVICE = '/dev/spidev0.0'
SPI_SPEED_KHZ = 800

class LahnLEDController:
    def __init__(self):
        self.neo = Pi5Neo(SPI_DEVICE, LED_COUNT, SPI_SPEED_KHZ)
        self.thread = None
        self.running = False

    def _run_pattern(self, pattern_func):
        def loop():
            self.running = True
            while self.running:
                pattern_func()
        self.stop()
        self.thread = threading.Thread(target=loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join()
            self.thread = None
        self.neo.clear_strip()
        self.neo.update_strip()

    def clear(self):
        self.stop()

    # === Custom LED Effects ===
    def set_idle(self):
        print("[LED] IDLE")
        def breathe():
            for b in range(0, 100, 4):
                if not self.running: return
                color = (0, 0, b)
                self.neo.fill_strip(*color)
                self.neo.update_strip()
                time.sleep(0.02)
            for b in range(100, 0, -4):
                if not self.running: return
                color = (0, 0, b)
                self.neo.fill_strip(*color)
                self.neo.update_strip()
                time.sleep(0.02)
        self._run_pattern(breathe)

    def set_listening(self):
        print("[LED] LISTENING")
        def blink():
            self.neo.fill_strip(80, 80, 80)  # Soft white
            self.neo.update_strip()
            time.sleep(0.6)
            self.neo.clear_strip()
            self.neo.update_strip()
            time.sleep(0.6)
        self._run_pattern(blink)

    def set_thinking(self):
        print("[LED] THINKING")
        def marquee():
            self.neo.clear_strip()
            t = int(time.time() * 15) % LED_COUNT
            for i in range(60):  # Increased length of the scanner
                idx = (t + i) % LED_COUNT
                self.neo.set_led_color(idx, 0, 40, 10)
            self.neo.update_strip()
            time.sleep(0.05)
        self._run_pattern(marquee)

    def set_speaking(self):
        print("[LED] SPEAKING")
        def wave():
            for i in range(LED_COUNT):
                brightness = int(abs((time.time()*10 + i) % 2 - 1) * 80)
                self.neo.set_led_color(i, 0, brightness, brightness)
            self.neo.update_strip()
            time.sleep(0.05)
        self._run_pattern(wave)

    def set_error(self):
        print("[LED] ERROR")
        def strobe():
            color = (255, 0, 0) if int(time.time() * 10) % 2 == 0 else (0, 0, 0)
            self.neo.fill_strip(*color)
            self.neo.fill_strip(*color)
            self.neo.update_strip()
            time.sleep(0.1)
        self._run_pattern(strobe)

# Example usage (manual test):
if __name__ == "__main__":
    led = LahnLEDController()
    try:
        led.set_idle()
        time.sleep(5)
        led.set_listening()
        time.sleep(5)
        led.set_thinking()
        time.sleep(5)
        led.set_speaking()
        time.sleep(5)
        led.set_error()
        time.sleep(5)
    finally:
        led.clear()
